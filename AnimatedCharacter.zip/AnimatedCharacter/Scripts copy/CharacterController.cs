using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterController : MonoBehaviour
{
    private bool grounded = true;
    public float jumpPower = 190;
    public float speed = 10f;
    private bool hasJumped = false;
    public Rigidbody rb;
    private Animator animator;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        // Do something

        if (Input.GetKey("w"))
        {
            transform.position += Vector3.forward * speed * Time.deltaTime;
            Run();
        }
        else
        {
            Idle();
        }
        if (Input.GetKey("a"))
        {
            transform.position += Vector3.left * speed * Time.deltaTime;
            Run();
        }
        else
        {
            Idle();
        }
        if (Input.GetKey("s"))//crouch
        {
            transform.position += Vector3.down * speed * Time.deltaTime;
        }
        else
        {
            Idle();
        }
        if (Input.GetKey("d"))
        {
            transform.position += Vector3.right * speed * Time.deltaTime;
            Run();
        
        }
        else
        {
            Idle();
        }
        if (Input.GetKeyDown("space"))
        {
            rb.AddForce(Vector3.up * jumpPower);
            Jump();
        }
        else
        {
            Idle();
        }

    }
    [ContextMenu("run")]
    void Run()
    {
        animator.SetInteger("speed", 5);
    }
    [ContextMenu("Jump")]
    void Jump()
    {
        animator.SetInteger("speed", 5);
    }

    
    [ContextMenu("Idle")]
    void Idle()
    {
        animator.SetInteger("speed", 0);
    }

    

    void FixedUpdate()
    {
        if (hasJumped)
        {
            rb.AddForce(transform.up * jumpPower);
            grounded = false;
            hasJumped = false;
        }
    }

}

    




